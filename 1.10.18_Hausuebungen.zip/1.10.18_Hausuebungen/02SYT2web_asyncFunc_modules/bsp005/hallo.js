let data = {
    name: function() {
        return "Welt";
    }
};

module.exports = data;
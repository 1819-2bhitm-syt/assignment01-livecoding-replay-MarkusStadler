const data = require("./hallo.js");

console.log(data.name());
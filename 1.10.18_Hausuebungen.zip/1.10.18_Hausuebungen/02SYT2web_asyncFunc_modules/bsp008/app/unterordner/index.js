console.log("ich bin unterordner/index.js");

require("./app.js");
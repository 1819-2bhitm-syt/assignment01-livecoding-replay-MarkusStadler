console.log("ich bin die app.js - Datei");

require("./hallo");